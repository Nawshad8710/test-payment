package com.mytestp.testp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestpApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestpApplication.class, args);
	}

}
